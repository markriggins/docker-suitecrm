<?php
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$suitecrm_version      = '7.6.4';
$suitecrm_timestamp    = '2016-05-30 17:00';
