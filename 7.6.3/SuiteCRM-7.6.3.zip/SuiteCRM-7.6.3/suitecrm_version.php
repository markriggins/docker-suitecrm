<?php
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$suitecrm_version      = '7.6.3';
$suitecrm_timestamp    = '2016-05-17 17:00';
